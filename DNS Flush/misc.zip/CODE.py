import os
import shutil
import sys


class DNS:
    def flushDNS(self):
        try:
            os.system('ipconfig/flushdns')

        except Exception as e:
            exc_type = type(e)
            return QMessageBox.warning(self, f'ERRO: {exc_type.__name__}',
                                       f'Description: {e}.')
        finally:
            QMessageBox.information(self, 'Success.', 'DNS flushed.')
            sys.exit()

    def displayDNS(self):
        try:
            os.system('ipconfig /displaydns > Log.txt')

        except Exception as e:
            exc_type = type(e)
            return QMessageBox.warning(self, f'ERRO: {exc_type.__name__}',
                                       f'Description: {e}.')
        finally:
            QMessageBox.information(self, 'Success.', 'Log has been created.')
            # self.moveLog()
            sys.exit()

    def moveLog(self):
        try:
            user = os.environ['USERNAME']
            pcName = os.environ['COMPUTERNAME']
            sourcePath = r'C:\\Users\\{}\\Log.txt'.format(user)
            destPath = r'C:\\Users\\{}\\Desktop\\{}.txt'.format(user, pcName)
            shutil.move(sourcePath, destPath)

        except Exception as e:
            exc_type = type(e)
            return QMessageBox.warning(self, f'ERRO: {exc_type.__name__}',
                                       f'Description: {e}.')